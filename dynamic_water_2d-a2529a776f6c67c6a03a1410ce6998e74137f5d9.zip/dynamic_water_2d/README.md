# dynamic_water_2d

Simple sideview water for Godot that reacts to forces applied to it.

## Usage

Clone the repository and copy over the addon.
The `water.tscn` scene in the addon is a preset that should work by default.

## Credits

Thanks to @HackTrout for writing the original code (https://github.com/HackTrout/2DDynamicWater).